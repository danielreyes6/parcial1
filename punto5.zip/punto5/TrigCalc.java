import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.FileInputStream;
import java.io.InputStream;

public class TrigCalc {
    public static void main(String[] args) throws Exception {
        String inputFile = null;
        if (args.length > 0) inputFile = args[0];
        InputStream is = System.in;
        if (inputFile != null) is = new FileInputStream(inputFile);
        CharStream input = CharStreams.fromStream(is);
        TrigLexer lexer = new TrigLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        TrigParser parser = new TrigParser(tokens);
        ParseTree tree = parser.program();
        ParseTreeWalker walker = new ParseTreeWalker();
        EvalListener eval = new EvalListener();
        walker.walk(eval, tree);
    }
}

class EvalListener extends TrigBaseListener {
    @Override
    public void exitSinExpr(TrigParser.SinExprContext ctx) {
        double value = Double.parseDouble(ctx.NUMBER().getText());
        System.out.println(Math.sin(Math.toRadians(value)));
    }

    @Override
    public void exitCosExpr(TrigParser.CosExprContext ctx) {
        double value = Double.parseDouble(ctx.NUMBER().getText());
        System.out.println(Math.cos(Math.toRadians(value)));
    }

    @Override
    public void exitTanExpr(TrigParser.TanExprContext ctx) {
        double value = Double.parseDouble(ctx.NUMBER().getText());
        System.out.println(Math.tan(Math.toRadians(value)));
    }
}

