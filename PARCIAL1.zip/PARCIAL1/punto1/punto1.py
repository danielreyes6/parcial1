
def get_token(expression):
    # Definir los estados del AFD
    INICIO = 0
    ENTERO = 1
    REAL = 2
    SUMA = 3
    INCR = 4
    ERROR = -1
    
    estado = INICIO
    i = 0
    n = len(expression)
    
    while i < n:
        char = expression[i]
        
        if estado == INICIO:
            if char.isdigit():
                estado = ENTERO
            elif char == '+':
                estado = SUMA
            else:
                estado = ERROR
        
        elif estado == ENTERO:
            if char.isdigit():
                estado = ENTERO
            elif char == '.':
                estado = REAL
            else:
                estado = ERROR
        
        elif estado == REAL:
            if char.isdigit():
                estado = REAL
            else:
                estado = ERROR
        
        elif estado == SUMA:
            if char == '+':
                estado = INCR
            else:
                estado = ERROR
        
        else:
            estado = ERROR
        
        i += 1
    
    # Determinar el token basado en el estado final
    if estado == ENTERO:
        return 'ENTERO'
    elif estado == REAL:
        return 'REAL'
    elif estado == SUMA:
        return 'SUMA'
    elif estado == INCR:
        return 'INCR'
    else:
        return None

# Probar la función con diferentes entradas
test_expressions = ['235', '15.65', '+', '++']
for expr in test_expressions:
    print(f"Expresión: {expr} -> Token: {get_token(expr)}")

