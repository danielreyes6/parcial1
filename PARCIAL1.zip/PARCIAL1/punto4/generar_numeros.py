import random

with open('numeros.txt', 'w') as f:
    for _ in range(1000):
        f.write(f"{random.randint(1, 1000)}\n")

